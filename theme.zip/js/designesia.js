/* --------------------------------------------------
 * © Copyright 2022 - Jonna by Designesia
 * --------------------------------------------------*/
(function($) {
	
	/* --------------------------------------------------
	 * predefined vars
	 * --------------------------------------------------*/
	var mobile_menu_show = 0;
	var v_count = '0';
	var mb;
	var instances = [];
	var $window = $(window);

	/* --------------------------------------------------
	 * header
	 * --------------------------------------------------*/
	
	function mark_menu(){
		jQuery('#mainmenu li a').each(function () {
                if (this.href.indexOf('#') != -1) {
					jQuery(this).removeClass('active');
                    var href = jQuery(this).attr('href');
                    if (window.location.hash==href) {
                        jQuery(this).addClass('active');
                    }
                }else{
						jQuery('#mainmenu li:first-child a').addClass('active');
				}
            });
	}
	/* --------------------------------------------------
	 * plugin | magnificPopup
	 * --------------------------------------------------*/
	function load_magnificPopup() {
		jQuery('.simple-ajax-popup-align-top').magnificPopup({
			type: 'ajax',
			alignTop: true,
			overflowY: 'scroll'
		});
		jQuery('.simple-ajax-popup').magnificPopup({
			type: 'ajax'
		});
		// zoom gallery
		jQuery('.zoom-gallery').magnificPopup({
			delegate: 'a',
			type: 'image',
			closeOnContentClick: false,
			closeBtnInside: false,
			mainClass: 'mfp-with-zoom mfp-img-mobile',
			image: {
				verticalFit: true,
				titleSrc: function(item) {
					return item.el.attr('title');
					//return item.el.attr('title') + ' &middot; <a class="image-source-link" href="'+item.el.attr('data-source')+'" target="_blank">image source</a>';
				}
			},
			gallery: {
				enabled: true
			},
			zoom: {
				enabled: true,
				duration: 300, // don't foget to change the duration also in CSS
				opener: function(element) {
					return element.find('img');
				}
			}
		});
		// popup youtube, video, gmaps
		jQuery('.popup-youtube, .popup-vimeo, .popup-gmaps').magnificPopup({
			disableOn: 700,
			type: 'iframe',
			mainClass: 'mfp-fade',
			removalDelay: 160,
			preloader: false,
			fixedContentPos: false
		});
		// Initialize popup as usual
		$('.image-popup-fit-width').magnificPopup({
		type: 'image',
		closeOnContentClick: true,
		image: {
			verticalFit: false
		}
	});


		$('.image-popup').magnificPopup({
			type: 'image',
			closeOnContentClick: true,
			mainClass: 'mfp-img-mobile',
			image: {
				verticalFit: true
			}
		});
		$('.image-popup-fit-width').magnificPopup({
			type: 'image',
			closeOnContentClick: true,
			image: {
				verticalFit: false
			}
		});
		$('.image-popup-no-margins').magnificPopup({
			type: 'image',
			closeOnContentClick: true,
			closeBtnInside: false,
			fixedContentPos: true,
			mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
			image: {
				verticalFit: true
			},
			zoom: {
				enabled: true,
				duration: 300 // don't foget to change the duration also in CSS
			}
		});
		$('.image-popup-gallery').magnificPopup({
			type: 'image',
			closeOnContentClick: false,
			closeBtnInside: false,
			mainClass: 'mfp-with-zoom mfp-img-mobile',
			image: {
				verticalFit: true,
				titleSrc: function(item) {
					return item.el.attr('title');
					//return item.el.attr('title') + ' &middot; <a class="image-source-link" href="'+item.el.attr('data-source')+'" target="_blank">image source</a>';
				}
			},
			gallery: {
				enabled: true
			}
		});
		$('.images-group').each(function() { // the containers for all your galleries
			$(this).magnificPopup({
				delegate: 'a', // the selector for gallery item
				type: 'image',
				gallery: {
				  enabled:true
				}
			});
		});
		
		$('.images-popup').magnificPopup({
		  delegate: 'a', // child items selector, by clicking on it popup will open
		  type: 'image'
		  // other options
		});
	}
	/* pf active */
	
	function pf_active(){
		if(window.location.hash=="#section-portfolio"){
				setTimeout(function(){
					$('.social-icons-fixed,.page-deco').addClass('pf-click');
			    }, 900);			
				setTimeout(function(){
					$('.pf-nav.left,.pf-nav.right').addClass('pf-click');
			    }, 1000);					
			}else{
				setTimeout(function(){
					$('.social-icons-fixed,.page-deco').removeClass('pf-click');
			    }, 900);
				setTimeout(function(){
					$('.pf-nav.left,.pf-nav.right').removeClass('pf-click');
			    }, 1000);					
			}
	}
	
	/* --------------------------------------------------
	 * plugin | enquire.js
	 * --------------------------------------------------*/
	function init_resize() {
		enquire.register("screen and (min-width: 992px)", {
			match: function() {
				jQuery('#mainmenu').show();
				mobile_menu_show = 1;
			},
			unmatch: function() {
				jQuery('#mainmenu').hide();
				jQuery('#content,#bg-overlay').removeClass("menu-open");
				mobile_menu_show = 0;
				jQuery("#menu-btn").show();
			}
		});
		enquire.register("screen and (max-width: 992px)", {
			match: function() {
				$('#top-bar').addClass("mobile");
				if(jQuery('body').hasClass('side-content')){
					jQuery('body').removeClass('side-layout');
				}
				
				$("#mainmenu").on("click", function() {
					if($('#top-bar').hasClass("mobile")){
						$(this).fadeOut();
						jQuery('#menu-btn').removeClass('menu-open');
					}
					mobile_menu_show = 0;
				});
			},
			unmatch: function() {
				$('#top-bar').removeClass("mobile");
				if(jQuery('body').hasClass('side-content')){
					jQuery('body').addClass('side-layout');
				}
			}
		});
		init();
		init_de();
		video_autosize();
		
		//jQuery('#gallery').isotope('reLayout');
		$('header').removeClass('smaller');
		$('header').removeClass('logo-smaller');
		$('header').removeClass('clone');
		
		var mx = window.matchMedia("(max-width: 992px)");
			if (mx.matches) {
				jQuery('.owl-slide-wrapper').find("img").css("height",$(window).innerHeight());
				jQuery('.owl-slide-wrapper').find("img").css("width","auto");
			}else{
				jQuery('.owl-slide-wrapper').find("img").css("width","100%");
				jQuery('.owl-slide-wrapper').find("img").css("height","auto");
			}
	};
	/* --------------------------------------------------
	 * plugin | owl carousel
	 * --------------------------------------------------*/
	function load_owl() {
		jQuery("#gallery-carousel").owlCarousel({
			items: 4,
			navigation: false,
			pagination: false
		});
		jQuery("#gallery-carousel-2").owlCarousel({
			items: 2,
			navigation: false,
			pagination: false
		});
		jQuery("#gallery-carousel-3").owlCarousel({
			items: 3,
			navigation: false,
			pagination: false
		});
		jQuery("#gallery-carousel-4").owlCarousel({
			items: 4,
			navigation: false,
			pagination: false
		});
		jQuery("#gallery-carousel-5").owlCarousel({
			items: 5,
			navigation: false,
			pagination: false
		});
		jQuery("#gallery-carousel-6").owlCarousel({
			items: 6,
			navigation: false,
			pagination: false
		});
		jQuery(".carousel-gallery").owlCarousel({
			items: 4,
			navigation: false,
			pagination: false
		});
		jQuery("#carousel-3,#carousel-services-3").owlCarousel({
			items: 3,
			navigation: false,
			pagination: true
		});
		
		jQuery("#blog-carousel").owlCarousel({
            center: true,
			items:4,
			loop:true,
			navigation: false,
			pagination: false,
			margin:20,
			responsive:{
				1000:{
					items:4
				},
				600:{
					items:2
				},
				0:{
					items:1
				}
			}
         });
		 
		 jQuery("#project-details-carousel").owlCarousel({
            center: false,
			items:2,
			loop:true,
			navigation: false,
			pagination: true,
			margin:0,
			responsive:{
				1000:{
					items:2
				},
				600:{
					items:2
				},
				0:{
					items:1
				}
			}
         });
		 
		 jQuery("#album-carousel-2").owlCarousel({
            center: false,
			items:4,
			loop:true,
			margin:0,
			nav: false,
			dots: false,
			responsive:{
				1000:{
					items:4
				},
				992:{
					items:3
				},
				600:{
					items:2
				},
				0:{
					items:1
				}
			}
         });
		
		jQuery("#testimonial-carousel").owlCarousel({
			items: 3,
			itemsDesktop: [1199, 2],
			itemsDesktopSmall: [980, 2],
			itemsTablet: [768, 1],
			itemsTabletSmall: false,
			itemsMobile: [479, 1],
			navigation: false,
		});
		jQuery("#testimonial-carousel-3").owlCarousel({
			items: 3,
			itemsDesktop: [1199, 2],
			itemsDesktopSmall: [980, 2],
			itemsTablet: [768, 1],
			itemsTabletSmall: false,
			itemsMobile: [479, 1],
			navigation: false,
		});
		jQuery("#logo-carousel").owlCarousel({
			items: 5,
			navigation: false,
			pagination: false,
			mouseDrag: false,
			touchDrag: false,
			autoPlay: true
		});
		jQuery("#contact-carousel").owlCarousel({
			items: 1,
			singleItem: true,
			navigation: false,
			pagination: false,
			autoPlay: true
		});
		jQuery(".text-slider").owlCarousel({
			items: 1,
			singleItem: true,
			navigation: false,
			pagination: false,
			mouseDrag: false,
			touchDrag: false,
			autoPlay: 2500,
			transitionStyle: "goDown"
		});
		jQuery(".blog-slide").owlCarousel({
			items: 1,
			singleItem: true,
			navigation: false,
			pagination: false,
			autoPlay: false
		});
		jQuery(".project-slide").owlCarousel({
			items: 1,
			singleItem: true,
			navigation: false,
			pagination: false,
			autoPlay: false,
			mouseDrag: false,
			touchDrag: true,
			transitionStyle: "fade"
		});
		jQuery(".testimonial-list").owlCarousel({
			items: 1,
			singleItem: true,
			navigation: false,
			pagination: true,
			autoPlay: true,
			mouseDrag: false,
			mouseDrag: false,
			touchDrag: true,
			transitionStyle: "fade"
		});
		jQuery("#custom-owl-slider").owlCarousel({
			items: 1,
			singleItem: true,
			navigation: false,
			pagination: false,
			autoPlay: true,
			mouseDrag: false,
			touchDrag: true,
			transitionStyle: "fade"
		});
		// Custom Navigation owlCarousel
		$(".pf-nav.left").on("click", function() {
			$('#album-carousel-2').trigger('prev.owl.carousel');
		});
		$(".pf-nav.right").on("click", function() {
			$('#album-carousel-2').trigger('next.owl.carousel');
		});
		
		jQuery('.owl-custom-nav').each(function() {
			var owl = $('.owl-custom-nav').next();
			var ow = parseInt(owl.css("height"), 10);
			$(this).css("margin-top", (ow / 2) - 25);
			owl.owlCarousel();
			// Custom Navigation Events
			$(".btn-next").on("click", function() {
				owl.trigger('owl.next');
			});
			$(".btn-prev").on("click", function() {
				owl.trigger('owl.prev');
			});
		});
		
		
		// custom navigation for slider
			var ows = $('#custom-owl-slider');
			var arr = $('.owl-slider-nav');
			var doc_height = $(window).innerHeight();
			arr.css("top", (doc_height / 2) - 25);
			ows.owlCarousel();
			// Custom Navigation Events
			arr.find(".next").on("click", function() {
				ows.trigger('owl.next');
			});
			arr.find(".prev").on("click", function() {
				ows.trigger('owl.prev');
			});
			
			jQuery(".owl-slide-wrapper").on("mouseenter", function() {
				arr.find(".next").css("right","40px");
				arr.find(".prev").css("left","40px");
			}).on("mouseleave", function() {
				arr.find(".next").css("right","-50px");
				arr.find(".prev").css("left","-50px");
			})
	}
	/* --------------------------------------------------
	 * plugin | isotope
	 * --------------------------------------------------*/
	function filter_gallery() {
		/*var $container = jQuery('#gallery');
		$container.isotope({
			itemSelector: '.item',
			filter: '*'
		});
		jQuery('#filters a').on("click", function() {
			var $this = jQuery(this);
			if ($this.hasClass('selected')) {
				return false;
			}
			var $optionSet = $this.parents();
			$optionSet.find('.selected').removeClass('selected');
			$this.addClass('selected');
			var selector = jQuery(this).attr('data-filter');
			$container.isotope({
				filter: selector
			});
			return false;
		});
		*/
		jQuery('#filters a').on("click", function() {
			var selector = jQuery(this).attr('data-filter');
			if(history.pushState) {
					history.pushState(null, null, jQuery(this).attr('href'));
				}else {
					location.hash = jQuery(this).attr('href');
				}
			
			jQuery('.item').fadeTo(300,1);
			jQuery(selector).fadeTo(300,.1);
			
			var $this = jQuery(this);
			if ($this.hasClass('selected')) {
				return false;
			}
			var $optionSet = $this.parents();
			$optionSet.find('.selected').removeClass('selected');
			$this.addClass('selected');
			var selector = jQuery(this).attr('data-filter');
			$container.isotope({
				filter: selector
			});
			return false;
		});
	}
	/* --------------------------------------------------
	 * plugin | fitvids
	 * --------------------------------------------------*/
	/*!
	* FitVids 1.0
	*
	* Copyright 2011, Chris Coyier - http://css-tricks.com + Dave Rupert - http://daverupert.com
	* Credit to Thierry Koblentz - http://www.alistapart.com/articles/creating-intrinsic-ratios-for-video/
	* Released under the WTFPL license - http://sam.zoy.org/wtfpl/
	*
	* Date: Thu Sept 01 18:00:00 2011 -0500
	*/
	!function(a){a.fn.fitVids=function(b){var c={customSelector:null},d=document.createElement("div"),e=document.getElementsByTagName("base")[0]||document.getElementsByTagName("script")[0];return d.className="fit-vids-style",d.innerHTML="&shy;<style> .fluid-width-video-wrapper { width: 100%; position: relative; padding: 0; } .fluid-width-video-wrapper iframe, .fluid-width-video-wrapper object, .fluid-width-video-wrapper embed { position: absolute; top: 0; left: 0; width: 100%; height: 100%; } </style>",e.parentNode.insertBefore(d,e),b&&a.extend(c,b),this.each(function(){var b=["iframe[src*='player.vimeo.com']","iframe[src*='www.youtube.com']","iframe[src*='www.kickstarter.com']","object","embed"];c.customSelector&&b.push(c.customSelector);var d=a(this).find(b.join(","));d.each(function(){var b=a(this);if(!("embed"==this.tagName.toLowerCase()&&b.parent("object").length||b.parent(".fluid-width-video-wrapper").length)){var c="object"==this.tagName.toLowerCase()||b.attr("height")?b.attr("height"):b.height(),d=b.attr("width")?b.attr("width"):b.width(),e=c/d;if(!b.attr("id")){var f="fitvid"+Math.floor(999999*Math.random());b.attr("id",f)}b.wrap('<div class="fluid-width-video-wrapper"></div>').parent(".fluid-width-video-wrapper").css("padding-top",100*e+"%"),b.removeAttr("height").removeAttr("width")}})})}}(jQuery);
	/* --------------------------------------------------
	 * back to top
	 * --------------------------------------------------*/
	var scrollTrigger = 500; // px
	var t = 0;
	function backToTop() {
		var scrollTop = $(window).scrollTop();
		if (scrollTop > scrollTrigger) {
			$('#back-to-top').addClass('show');
			$('#back-to-top').removeClass('hide');
			t = 1;
		}
		
		if (scrollTop < scrollTrigger && t==1) {
			$('#back-to-top').addClass('hide');
		}
		
		$('#back-to-top').on('click', function(e) {
			e.preventDefault();
			$('html,body').stop(true).animate({
				scrollTop: 0
			}, 700);
		});
	};

	/* --------------------------------------------------
	 * counting number
	 * --------------------------------------------------*/
	function de_counter() {
		jQuery('.timer').each(function() {
			var imagePos = jQuery(this).offset().top;
			var topOfWindow = jQuery(window).scrollTop();
			if (imagePos < topOfWindow + jQuery(window).height() && v_count == '0') {
				jQuery(function($) {
					// start all the timers
					jQuery('.timer').each(count);

					function count(options) {
						v_count = '1';
						var $this = jQuery(this);
						options = $.extend({}, options || {}, $this.data('countToOptions') || {});
						$this.countTo(options);
					}
				});
			}
		});
	}
	/* --------------------------------------------------
	 * progress bar
	 * --------------------------------------------------*/

	text_rotate = function(){
    var quotes = $(".text-rotate-wrap .text-item");
    var quoteIndex = -1;
    
    function showNextQuote() {
        ++quoteIndex;
        quotes.eq(quoteIndex % quotes.length)
            .fadeIn(1)
            .delay(1500)
            .fadeOut(1, showNextQuote);
    }
    
    showNextQuote();
    
	};
	/* --------------------------------------------------
	 * custom background
	 * --------------------------------------------------*/
	function custom_bg() {
		$("div,section,span").css('background-color', function() {
			return jQuery(this).data('bgcolor');
		});
		$("body,div,section").css('background-image', function() {
			return jQuery(this).data('bgimage');
		});
		$("div,section,.section").css('background-size', function() {
			return 'cover';
		});
		$('.img-url').each(function() {
			$img_name = $(this).parent().find('img').attr('src');
			//alert('url("'+$img_name+'")');
			$(this).css('background','url('+$img_name+')');
		});
		
		/*$(".img-url").css('background', function() {
			return 'url("images/misc/pic-1.jpg")';
		});*/
		
		$("div,section").css('background-size', function() {
			return 'cover';
		});
		
		$(".img-url").css('background-position', function() {
			return 'top center';
		});
		
		
	}
	
	
	function get_url() {
		$('.carousel-item').on("click", function() {
			window.location = jQuery(this).data('url');
		});
	}
	
	/* --------------------------------------------------
	 * custom elements
	 * --------------------------------------------------*/
	function custom_elements() {
		// --------------------------------------------------
		// tabs
		// --------------------------------------------------
		jQuery('.de_tab').find('.de_tab_content > div').hide();
		jQuery('.de_tab').find('.de_tab_content > div:first').show();
		jQuery('li').find('.v-border').fadeTo(150, 0);
		jQuery('li.active').find('.v-border').fadeTo(150, 1);
		jQuery('.de_nav li').on("click", function() {
			jQuery(this).parent().find('li').removeClass("active");
			jQuery(this).addClass("active");
			jQuery(this).parent().parent().find('.v-border').fadeTo(150, 0);
			jQuery(this).parent().parent().find('.de_tab_content > div').hide();
			var indexer = jQuery(this).index(); //gets the current index of (this) which is #nav li
			jQuery(this).parent().parent().find('.de_tab_content > div:eq(' + indexer + ')').fadeIn(); //uses whatever index the link has to open the corresponding box 
			jQuery(this).find('.v-border').fadeTo(150, 1);
		});
		// request quote function
		var rq_step = 1;
		jQuery('#request_form .btn-right').on("click", function() {
			var rq_name = $('#rq_name').val();
			var rq_email = $('#rq_email').val();
			var rq_phone = $('#rq_phone').val();
			if (rq_step == 1) {
				if (rq_name.length == 0) {
					$('#rq_name').addClass("error_input");
				} else {
					$('#rq_name').removeClass("error_input");
				}
				if (rq_email.length == 0) {
					$('#rq_email').addClass("error_input");
				} else {
					$('#rq_email').removeClass("error_input");
				}
				if (rq_phone.length == 0) {
					$('#rq_phone').addClass("error_input");
				} else {
					$('#rq_phone').removeClass("error_input");
				}
			}
			if (rq_name.length != 0 && rq_email.length != 0 && rq_phone.length != 0) {
				jQuery("#rq_step_1").hide();
				jQuery("#rq_step_2").fadeIn();
			}
		});
		// --------------------------------------------------
		// tabs
		// --------------------------------------------------
		jQuery('.de_review').find('.de_tab_content > div').hide();
		jQuery('.de_review').find('.de_tab_content > div:first').show();
		//jQuery('.de_review').find('.de_nav li').fadeTo(150,.5);
		jQuery('.de_review').find('.de_nav li:first').fadeTo(150, 1);
		jQuery('.de_nav li').on("click", function() {
			jQuery(this).parent().find('li').removeClass("active");
			//jQuery(this).parent().find('li').fadeTo(150,.5);
			jQuery(this).addClass("active");
			jQuery(this).fadeTo(150, 1);
			jQuery(this).parent().parent().find('.de_tab_content > div').hide();
			var indexer = jQuery(this).index(); //gets the current index of (this) which is #nav li
			jQuery(this).parent().parent().find('.de_tab_content > div:eq(' + indexer + ')').show(); //uses whatever index the link has to open the corresponding box 
		});
		// --------------------------------------------------
		// toggle
		// --------------------------------------------------
		jQuery(".toggle-list h2").addClass("acc_active");
		jQuery(".toggle-list h2").toggle(function() {
			jQuery(this).addClass("acc_noactive");
			jQuery(this).next(".ac-content").slideToggle(200);
		}, function() {
			jQuery(this).removeClass("acc_noactive").addClass("acc_active");
			jQuery(this).next(".ac-content").slideToggle(200);
		})
	}
	/* --------------------------------------------------
	 * video autosize
	 * --------------------------------------------------*/
	function video_autosize() {
		jQuery('.de-video-container').each(function() {
			var height_1 = jQuery(this).css("height");
			var height_2 = jQuery(this).find(".de-video-content").css("height");
			var newheight = (height_1.substring(0, height_1.length - 2) - height_2.substring(0, height_2.length - 2)) / 2;
			jQuery(this).find('.de-video-overlay').css("height", height_1);
			jQuery(this).find(".de-video-content").animate({
				'margin-top': newheight
			}, 'fast');
		});
	}
	/* --------------------------------------------------
	 * center x and y
	 * --------------------------------------------------*/
	function center_xy() {
		jQuery('.center-xy').each(function() {
			jQuery(this).parent().find("img").on('load', function() {
				var w = parseInt(jQuery(this).parent().find(".center-xy").css("width"), 10);
				var h = parseInt(jQuery(this).parent().find(".center-xy").css("height"), 10);
				var pic_w = jQuery(this).css("width");
				var pic_h = jQuery(this).css("height");
				jQuery(this).parent().find(".center-xy").css("left", parseInt(pic_w, 10) / 2 - w / 2);
				jQuery(this).parent().find(".center-xy").css("top", parseInt(pic_h, 10) / 2 - h / 2);
				jQuery(this).parent().find(".bg-overlay").css("width", pic_w);
				jQuery(this).parent().find(".bg-overlay").css("height", pic_h);
			}).each(function() {
				if (this.complete) $(this).load();
			});
		});
	}
	/* --------------------------------------------------
	 * add arrow for mobile menu
	 * --------------------------------------------------*/
	function menu_arrow() {
		// mainmenu create span
		jQuery('#mainmenu li a').each(function() {
			if ($(this).next("ul").length > 0) {
				$("<span></span>").insertAfter($(this));
			}
		});
		// mainmenu arrow click
		jQuery("#mainmenu > li > span").on("click", function() {
			$('header').css("height", "auto");
			var iteration = $(this).data('iteration') || 1;
			switch (iteration) {
				case 1:
					$(this).addClass("active");
					$(this).parent().find("ul:first").css("height", "auto");
					var curHeight = $(this).parent().find("ul:first").height();
					$(this).parent().find("ul:first").css("height", "0");
					$(this).parent().find("ul:first").animate({
						'height': curHeight
					}, 400, 'easeInOutQuint');
					break;
				case 2:
					$(this).removeClass("active");
					$(this).parent().find("ul:first").animate({
						'height': "0"
					}, 400, 'easeInOutQuint');
					break;
			}
			iteration++;
			if (iteration > 2) iteration = 1;
			$(this).data('iteration', iteration);
		});
		jQuery("#mainmenu > li > ul > li > span").on("click", function() {
			var iteration = $(this).data('iteration') || 1;
			switch (iteration) {
				case 1:
					$(this).addClass("active");
					$(this).parent().find("ul:first").css("height", "auto");
					$(this).parent().parent().parent().find("ul:first").css("height", "auto");
					var curHeight = $(this).parent().find("ul:first").height();
					$(this).parent().find("ul:first").css("height", "0");
					$(this).parent().find("ul:first").animate({
						'height': curHeight
					}, 400, 'easeInOutQuint');
					break;
				case 2:
					$(this).removeClass("active");
					$(this).parent().find("ul:first").animate({
						'height': "0"
					}, 400, 'easeInOutQuint');
					break;
			}
			iteration++;
			if (iteration > 2) iteration = 1;
			$(this).data('iteration', iteration);
		});
	}
	/* --------------------------------------------------
	 * show gallery item sequence
	 * --------------------------------------------------*/
	sequence = function(){
		var sq = jQuery(".sequence > .sq-item .picframe");
		var count = sq.length;
		sq.addClass("slideInUp");
		for (var i = 0; i <= count; i++) {
		  sqx = jQuery(".sequence > .sq-item:eq("+i+") .picframe");
		  sqx.attr('data-wow-delay',(i/8)+'s');
		}		
	}
	/* --------------------------------------------------
	 * show gallery item sequence
	 * --------------------------------------------------*/
	sequence_a = function(){
		var sq = jQuery(".sequence > .sq-item");
		var count = sq.length;
		sq.addClass("fadeInRight");
		for (var i = 0; i <= count; i++) {
		  sqx = jQuery(".sequence > .sq-item:eq("+i+")");
		  sqx.attr('data-wow-delay',(i/8)+'s');
		}		
	}
	/* --------------------------------------------------
	 * custom scroll
	 * --------------------------------------------------*/
	$.fn.moveIt = function(){	  
	  $(this).each(function(){
		instances.push(new moveItItem($(this)));
	  });
	}
	moveItItemNow = function(){
	var scrollTop = $window.scrollTop();
		instances.forEach(function(inst){
		  inst.update(scrollTop);
		});
	}
	var moveItItem = function(el){
	  this.el = $(el);
	  this.speed = parseInt(this.el.attr('data-scroll-speed'));
	};
	moveItItem.prototype.update = function(scrollTop){
	  var pos = scrollTop / this.speed;
	  this.el.css('transform', 'translateY(' + pos + 'px)');
	};
	$(function(){
	  $('[data-scroll-speed]').moveIt();
	});
	/* --------------------------------------------------
	 * multiple function
	 * --------------------------------------------------*/
	function init() {
		var sh = jQuery('#de-sidebar').css("height");
		var dh = jQuery(window).innerHeight();
		var h = parseInt(sh) - parseInt(dh);

		function scrolling() {
			var mq = window.matchMedia("(min-width: 992px)");
			var ms = window.matchMedia("(min-width: 768px)");
			var mx = window.matchMedia("(max-width: 992px)");
			
			
			if (mx.matches) {
				jQuery('#mainmenu').hide();
				jQuery('#content,#bg-overlay,#menu-btn').removeClass("menu-open");
				mobile_menu_show = 0;
			}
			
			if (mq.matches) {
				var distanceY = window.pageYOffset || document.documentElement.scrollTop,
					shrinkOn = 0,
					header = jQuery("header");
				if (distanceY > shrinkOn) {
					header.addClass("smaller");
				} else {
					if (header.hasClass('smaller')) {
						header.removeClass('smaller');
					}
				}
			}
			if (mq.matches) {
				if (jQuery("header").hasClass("side-header")) {
					if (jQuery(document).scrollTop() >= h) {
						jQuery('#de-sidebar').css("position", "fixed");
						if (parseInt(sh) > parseInt(dh)) {
							jQuery('#de-sidebar').css("top", -h);
						}
						jQuery('#main').addClass("col-md-offset-3");
						jQuery('h1#logo img').css("padding-left", "7px");
						jQuery('header .h-content').css("padding-left", "7px");
						jQuery('#mainmenu li').css("width", "103%");
					} else {
						jQuery('#de-sidebar').css("position", "relative");
						if (parseInt(sh) > parseInt(dh)) {
							jQuery('#de-sidebar').css("top", 0);
						}
						jQuery('#main').removeClass("col-md-offset-3");
						jQuery('h1#logo img').css("padding-left", "0px");
						jQuery('header .h-content').css("padding-left", "0px");
						jQuery('#mainmenu li').css("width", "100%");
					}
				}

			}
		}
		
		// --------------------------------------------------
	// looping background
	// --------------------------------------------------
	 
		scrolling();
		
		
		jQuery(".btn-rsvp").on("click", function() {
			var iteration = $(this).data('iteration') || 1;
			switch (iteration) {
				case 1:
					jQuery('#popup-box').addClass('popup-show');					
					jQuery('#popup-box').removeClass('popup-hide');
					break;
				case 2:
					
					break;
			}
			iteration++;
			if (iteration > 2) iteration = 1;
			$(this).data('iteration', iteration);
		});
		
		jQuery(".btn-close").on("click", function() {
			var iteration = $(this).data('iteration') || 1;
			switch (iteration) {
				case 1:
					jQuery('#popup-box').addClass('popup-hide');					
					jQuery('#popup-box').removeClass('popup-show');
					break;
				case 2:
					
					break;
			}
			iteration++;
			if (iteration > 2) iteration = 1;
			$(this).data('iteration', iteration);
		});
	}
	/* --------------------------------------------------
	 * multiple function
	 * --------------------------------------------------*/
	function init_de() {
		jQuery('.de-team-list').each(function() {
			jQuery(this).find("img").on('load', function() {
				var w = jQuery(this).css("width");
				var h = jQuery(this).css("height");
				//nh = (h.substring(0, h.length - 2)/2)-48;
				jQuery(this).parent().parent().find(".team-pic").css("height", h);
				jQuery(this).parent().parent().find(".team-desc").css("width", w);
				jQuery(this).parent().parent().find(".team-desc").css("height", h);
				jQuery(this).parent().parent().find(".team-desc").css("top", h);
			}).each(function() {
				if (this.complete) $(this).load();
			});
		});
		jQuery(".de-team-list").on("mouseenter", function() {
				var h;
				h = jQuery(this).find("img").css("height");
				jQuery(this).find(".team-desc").stop(true).animate({
					'top': "0px"
				}, 350, 'easeOutQuad');
				jQuery(this).find("img").stop(true).animate({
					'margin-top': "-100px"
				}, 400, 'easeOutQuad');
			}).on("mouseleave", function() {
				var h;
				h = jQuery(this).find("img").css("height");
				jQuery(this).find(".team-desc").stop(true).animate({
					'top': h
				}, 350, 'easeOutQuad');
				jQuery(this).find("img").stop(true).animate({
					'margin-top': "0px"
				}, 400, 'easeOutQuad');
			})
			// portfolio
		jQuery('.item .picframe').each(function() {
			jQuery(this).find("img").css("width", "100%");
			jQuery(this).find("img").css("height", "auto");
			jQuery(this).find("img").on('load', function() {
				var w = jQuery(this).css("width");
				var h = jQuery(this).css("height");
				//nh = (h.substring(0, h.length - 2)/2)-48;
				jQuery(this).parent().css("height", h);
			}).each(function() {
				if (this.complete) $(this).load();
			});
		});
		// --------------------------------------------------
		// portfolio hover
		// --------------------------------------------------
		jQuery('.overlay').fadeTo(1, 0);
		// gallery hover
		jQuery(".item .picframe").on("mouseenter", function() {
			jQuery(this).parent().find(".overlay").width(jQuery(this).find("img").css("width"));
			jQuery(this).parent().find(".overlay").height(jQuery(this).find("img").css("height"));
			jQuery(this).parent().find(".overlay").stop(true).fadeTo(200, .9);
			var picheight = jQuery(this).find("img").css("height");
			var newheight;
			newheight = (picheight.substring(0, picheight.length - 2) / 2) - 10;
			//alert(newheight);
			//jQuery(this).parent().find(".pf_text").stop(true).animate({'margin-top': newheight},200,'easeOutCubic');
			jQuery(this).parent().find(".pf_text").css('margin-top', newheight);
			jQuery(this).parent().find(".pf_text").stop(true).animate({
				'opacity': '1'
			}, 1000, 'easeOutCubic');
			var w = jQuery(this).find("img").css("width");
			var h = jQuery(this).find("img").css("height");
			var w = parseInt(w, 10);
			var h = parseInt(h, 10);
			var $scale = 1;
			//alert(w);
			jQuery(this).find("img").stop(true).animate({
				width: w * $scale,
				height: h * $scale,
				'margin-left': -w * ($scale - 1) / 2,
				'margin-top': -h * ($scale - 1) / 2
			}, 400, 'easeOutCubic');
		}).on("mouseleave", function() {
			var newheight;
			var picheight = jQuery(this).find("img").css("height");
			newheight = (picheight.substring(0, picheight.length - 2) / 2) - 10;
			//jQuery(this).parent().find(".pf_text").stop(true).animate({'margin-top': newheight - 30},200,'easeOutCubic');
			jQuery(this).parent().find(".pf_text").stop(true).animate({
				'opacity': '0'
			}, 400, 'easeOutCubic');
			jQuery(this).parent().find(".overlay").stop(true).fadeTo(200, 0);
			jQuery(this).find("img").stop(true).animate({
				width: '100%',
				height: '100%',
				'margin-left': 0,
				'margin-top': 0
			}, 400, 'easeOutQuad');
		})
		jQuery('.overlay').fadeTo(1, 0);
		$.stellar('refresh');
		
		var preloader_pos = parseInt(jQuery(window).innerHeight()/2)-30;
		$(".preloader1").css("top",preloader_pos);
	}
	
	/* --------------------------------------------------
	 * center-y
	 * --------------------------------------------------*/
	function centerY(){
			jQuery('.full-height').each(function() {
				var dh = jQuery(window).innerHeight();
				jQuery(this).css("height",dh);
			});
		}
		
	/* --------------------------------------------------
	 * progress bar
	 * --------------------------------------------------*/
	function de_progress() {
		jQuery('.de-progress').each(function() {
			var pos_y = jQuery(this).offset().top;
			var value = jQuery(this).find(".progress-bar").attr('data-value');
			var topOfWindow = jQuery(window).scrollTop();
			
				jQuery(this).find(".progress-bar").css({
					'width': value
				}, "slow");
			
			jQuery(this).find('.value').text(jQuery(this).find('.progress-bar').attr('data-value'));
		});
	}
	/* --------------------------------------------------
	 * document ready
	 * --------------------------------------------------*/
	jQuery(document).ready(function() {
		'use strict';
		$("body").show();
		$('body').addClass('de_dark');
		// --------------------------------------------------
		// blog list hover
		// --------------------------------------------------
		jQuery(".blog-list").on("mouseenter", function() {
				var v_height = jQuery(this).find(".blog-slide").css("height");
				var v_width = jQuery(this).find(".blog-slide").css("width");
				var newheight = (v_height.substring(0, v_height.length - 2) / 2) - 40;
				jQuery(this).find(".owl-arrow").css("margin-top", newheight);
				jQuery(this).find(".owl-arrow").css("width", v_width);
				jQuery(this).find(".owl-arrow").fadeTo(150, 1);
				//alert(v_height);
			}).on("mouseleave", function() {
				jQuery(this).find(".owl-arrow").fadeTo(150, 0);
			})
			//  logo carousel hover
		jQuery("#logo-carousel img").on("mouseenter", function() {
			jQuery(this).fadeTo(150, .5);
		}).on("mouseleave", function() {
			jQuery(this).fadeTo(150, 1);
		})
		if ($('#back-to-top').length) {
			backToTop();
		}
		jQuery(".nav-exit").on("click", function() {
			$.magnificPopup.close();
		});
		// --------------------------------------------------
		// navigation for mobile
		// --------------------------------------------------
		jQuery('#menu-btn').on("click", function() {
				if (mobile_menu_show == 0) {
					jQuery(this).addClass('menu-open');
					jQuery('#mainmenu').fadeIn();
					jQuery('#content,#bg-overlay').addClass("menu-open");
					mobile_menu_show = 1;
				} else {
					jQuery(this).removeClass('menu-open');
					jQuery('#mainmenu').fadeOut();
					jQuery('#content,#bg-overlay').removeClass("menu-open");
					mobile_menu_show = 0;
				}
			})
		jQuery("a.btn").on("click", function(evn) {
			if (this.href.indexOf('#') != -1) {
				evn.preventDefault();
				jQuery('html,body').scrollTo(this.hash, this.hash);
			}
		});
		jQuery('.de-gallery .item .icon-info').on("click", function() {
			jQuery('.page-overlay').show();
			url = jQuery(this).attr("data-value");
			jQuery("#loader-area .project-load").load(url, function() {
				jQuery("#loader-area").slideDown(500, function() {
					jQuery('.page-overlay').hide();
					jQuery('html, body').animate({
						scrollTop: jQuery('#loader-area').offset().top - 70
					}, 500, 'easeOutCubic');
					//
					jQuery(".image-slider").owlCarousel({
						items: 1,
						singleItem: true,
						navigation: false,
						pagination: true,
						autoPlay: false
					});
					jQuery(".container").fitVids();
					jQuery('#btn-close-x').on("click", function() {
						jQuery("#loader-area").slideUp(500, function() {
							jQuery('html, body').animate({
								scrollTop: jQuery('#section-portfolio').offset().top - 70
							}, 500, 'easeOutCirc');
						});
						return false;
					});
				});
			});
		});
		jQuery('.de-gallery .item').on("click", function() {
			$('#navigation').show();
		});
		// btn arrow up
		jQuery(".arrow-up").on("click", function() {
			jQuery(".coming-soon .coming-soon-content").fadeOut("medium", function() {
				jQuery("#hide-content").fadeIn(600, function() {
					jQuery('.arrow-up').animate({
						'bottom': '-40px'
					}, "slow");
					jQuery('.arrow-down').animate({
						'top': '0'
					}, "slow");
				});
			});
		});
		// btn arrow down
		jQuery(".arrow-down").on("click", function() {
			jQuery("#hide-content").fadeOut("slow", function() {
				jQuery(".coming-soon .coming-soon-content").fadeIn(800, function() {
					jQuery('.arrow-up').animate({
						'bottom': '0px'
					}, "slow");
					jQuery('.arrow-down').animate({
						'top': '-40'
					}, "slow");
				});
			});
		});
		/* --------------------------------------------------
		 * window | on resize
		 * --------------------------------------------------*/
		$(window).on("resize", function() {
			init_resize();
			init();
			centerY();
			
			var wh = $(window).innerHeight();
			var hash = window.location.hash;			
			var sh = $(hash).height();			
			$('#content').css('height',sh);
			jQuery('#menu-btn').removeClass('menu-open');
			
		});
		/* --------------------------------------------------
		 * window | on scroll
		 * --------------------------------------------------*/
		jQuery(window).on("scroll", function() {
			/* functions */
			de_counter();
			de_progress();
			init();
			backToTop();
			moveItItemNow();
			/* plugin | stellar */
			$.stellar({
				horizontalScrolling: false,
				verticalOffset: 0
			});
			/* fade base scroll position */
			var target = $('.fadeScroll');
			var targetHeight = target.outerHeight();
			var scrollPercent = (targetHeight - window.scrollY) / targetHeight;
			if (scrollPercent >= 0) {
				target.css('opacity', scrollPercent);
			}else{
				target.css('opacity', 0);
			}
			// custom page with background on side
			jQuery('.side-bg').each(function() {
				jQuery(this).find(".image-container").css("height", jQuery(this).find(".image-container").parent().css("height"));
			});
			/* go to anchor */
			mark_menu();
		});
		
		$(function(){
     	"use strict";
        var x = 0;
        setInterval(function(){
            x-=1;
            $('.bg-loop').css('background-position', x + 'px 0');
        }, 50);
    })
	});
	
	/* --------------------------------------------------
	 * window | on load
	 * --------------------------------------------------*/
	jQuery(window).on("load", function() {
		new WOW().init();
		load_magnificPopup();
		center_xy();
		init_de();
		init_resize();
		de_progress();

		// --------------------------------------------------
		// custom positiion
		// --------------------------------------------------
		var $doc_height = jQuery(window).innerHeight();
		jQuery('#homepage #content.content-overlay').css("margin-top", $doc_height);
		//jQuery('.full-height').css("height", $doc_height);
		//var picheight = jQuery('.center-y').css("height");
		//picheight = parseInt(picheight, 10);
		//jQuery('.center-y').css('margin-top', (($doc_height - picheight) / 2)-100);
		jQuery('.full-height .de-video-container').css("min-height", $doc_height);
		
		
		centerY();
		video_autosize();
		filter_gallery();
		custom_bg();
		get_url();
		menu_arrow();
		load_owl();
		custom_elements();
		init();
		pf_active();
		// hide preloader after loaded
		jQuery('#preloader').fadeOut(500);

		// one page navigation
		/**
		 * This part causes smooth scrolling using scrollto.js
		 * We target all a tags inside the nav, and apply the scrollto.js to it.
		 */
	jQuery("#homepage nav a, .scroll-to").on("click", function(evn) {
		if (this.href.indexOf('#') != -1) {
			
			evn.preventDefault();
			var section_name = jQuery(this).attr('href');
			
			if(history.pushState) {
				history.pushState(null, null, jQuery(this).attr('href'));
			}else {
				location.hash = jQuery(this).attr('href');
			}
			
			jQuery('#content,#bg-overlay').removeClass("menu-open");
			
			jQuery('#mainmenu li a').removeClass('active');
            jQuery(this).addClass('active');
			
			//jQuery('#content').css('height',jQuery(section_name).css('height'));
			
			jQuery('#content').animate({
					'height': jQuery(section_name).css('height')
			}, 400, 'easeOutCubic', function() {
					jQuery('#content').scrollTo(section_name, section_name);
			});
			
			
			
			jQuery('.img-url').removeClass('to-size');
			jQuery(section_name).find('.img-url').addClass('to-2x');
			jQuery(section_name).find('.img-url').removeClass('to-2x');
			jQuery(section_name).find('.img-url').addClass('to-size');

		}
		
		var $container = jQuery('#gallery');
		$container.isotope({
			itemSelector: '.item',
			filter: '*'
		});
		
		pf_active();			
		
	});
	
	sequence();
	sequence_a();
	
	var init_height = jQuery('#section-home').css('height');
	jQuery('#content').css('height',init_height);
	
	var hash = window.location.hash;
	jQuery('#content').scrollTo(hash, hash);
	jQuery('#content').css('height',jQuery(hash).css('height'));
	
	jQuery(hash).find('.img-url').addClass('to-size');
		

	mark_menu();
	
	if(!window.location.hash){
		if($('body').hasClass('homepage')){
			jQuery('#mainmenu li:first-child a').addClass('active');
		}
	}
	
	});

})(jQuery);